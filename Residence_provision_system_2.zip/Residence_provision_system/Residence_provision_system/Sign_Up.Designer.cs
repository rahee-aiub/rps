﻿namespace Residence_provision_system
{
    partial class Sign_Up
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Sign_Up));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.browse_buttom = new System.Windows.Forms.Button();
            this.renterImage = new System.Windows.Forms.PictureBox();
            this.ConfirmButton = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.RentedFlatComboBox = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.OfficeContNoTextBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.OffAddressTextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.EmailTextbox = new System.Windows.Forms.TextBox();
            this.ContactNoTextbox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.PAddressTextBox = new System.Windows.Forms.TextBox();
            this.MotherLastNameTextBox = new System.Windows.Forms.TextBox();
            this.MotherFirstNameTextBox = new System.Windows.Forms.TextBox();
            this.FatherLastNameTextBox = new System.Windows.Forms.TextBox();
            this.FatherFirstNameTextBox = new System.Windows.Forms.TextBox();
            this.LastNameTextBox = new System.Windows.Forms.TextBox();
            this.FirstNameTextBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.renterImage)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(31, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(45, 45);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 107;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(129, 384);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(121, 20);
            this.textBox2.TabIndex = 106;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(59, 387);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(62, 13);
            this.label16.TabIndex = 105;
            this.label16.Text = "Occupation";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(596, 71);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(36, 13);
            this.label15.TabIndex = 104;
            this.label15.Text = "Image";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(533, 378);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 13);
            this.label14.TabIndex = 103;
            this.label14.Text = "Password";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(599, 375);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(112, 20);
            this.textBox1.TabIndex = 102;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(550, 348);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(78, 13);
            this.label13.TabIndex = 101;
            this.label13.Text = "family members";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBox1.Location = new System.Drawing.Point(634, 344);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(77, 21);
            this.comboBox1.TabIndex = 100;
            // 
            // browse_buttom
            // 
            this.browse_buttom.Location = new System.Drawing.Point(587, 304);
            this.browse_buttom.Name = "browse_buttom";
            this.browse_buttom.Size = new System.Drawing.Size(75, 23);
            this.browse_buttom.TabIndex = 99;
            this.browse_buttom.Text = "browse";
            this.browse_buttom.UseVisualStyleBackColor = true;
            this.browse_buttom.Click += new System.EventHandler(this.browse_buttom_Click_1);
            // 
            // renterImage
            // 
            this.renterImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.renterImage.Location = new System.Drawing.Point(536, 99);
            this.renterImage.Name = "renterImage";
            this.renterImage.Size = new System.Drawing.Size(175, 175);
            this.renterImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.renterImage.TabIndex = 98;
            this.renterImage.TabStop = false;
            // 
            // ConfirmButton
            // 
            this.ConfirmButton.Location = new System.Drawing.Point(553, 415);
            this.ConfirmButton.Name = "ConfirmButton";
            this.ConfirmButton.Size = new System.Drawing.Size(106, 29);
            this.ConfirmButton.TabIndex = 97;
            this.ConfirmButton.Text = "Confirm";
            this.ConfirmButton.UseVisualStyleBackColor = true;
            this.ConfirmButton.Click += new System.EventHandler(this.ConfirmButton_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(260, 387);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(68, 13);
            this.label12.TabIndex = 96;
            this.label12.Text = "Rented Date";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(334, 384);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(181, 20);
            this.dateTimePicker1.TabIndex = 95;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(391, 348);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(62, 13);
            this.label11.TabIndex = 94;
            this.label11.Text = "Rented Flat";
            // 
            // RentedFlatComboBox
            // 
            this.RentedFlatComboBox.FormattingEnabled = true;
            this.RentedFlatComboBox.Items.AddRange(new object[] {
            "A-1",
            "A-2",
            "A-3",
            "A-4",
            "A-5",
            "A-6",
            "B-1",
            "B-2",
            "B-3",
            "B-4",
            "B-5",
            "B-6"});
            this.RentedFlatComboBox.Location = new System.Drawing.Point(466, 344);
            this.RentedFlatComboBox.Name = "RentedFlatComboBox";
            this.RentedFlatComboBox.Size = new System.Drawing.Size(49, 21);
            this.RentedFlatComboBox.TabIndex = 93;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(28, 344);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(95, 13);
            this.label10.TabIndex = 92;
            this.label10.Text = "Office Contact No.";
            // 
            // OfficeContNoTextBox
            // 
            this.OfficeContNoTextBox.Location = new System.Drawing.Point(129, 341);
            this.OfficeContNoTextBox.Name = "OfficeContNoTextBox";
            this.OfficeContNoTextBox.Size = new System.Drawing.Size(141, 20);
            this.OfficeContNoTextBox.TabIndex = 91;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(45, 307);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 13);
            this.label9.TabIndex = 90;
            this.label9.Text = "Office Address";
            // 
            // OffAddressTextBox
            // 
            this.OffAddressTextBox.Location = new System.Drawing.Point(129, 304);
            this.OffAddressTextBox.Name = "OffAddressTextBox";
            this.OffAddressTextBox.Size = new System.Drawing.Size(386, 20);
            this.OffAddressTextBox.TabIndex = 89;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(331, 231);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 13);
            this.label8.TabIndex = 88;
            this.label8.Text = "Email";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(59, 231);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 13);
            this.label7.TabIndex = 87;
            this.label7.Text = "Contact No.";
            // 
            // EmailTextbox
            // 
            this.EmailTextbox.Location = new System.Drawing.Point(370, 228);
            this.EmailTextbox.Name = "EmailTextbox";
            this.EmailTextbox.Size = new System.Drawing.Size(145, 20);
            this.EmailTextbox.TabIndex = 86;
            // 
            // ContactNoTextbox
            // 
            this.ContactNoTextbox.Location = new System.Drawing.Point(129, 228);
            this.ContactNoTextbox.Name = "ContactNoTextbox";
            this.ContactNoTextbox.Size = new System.Drawing.Size(141, 20);
            this.ContactNoTextbox.TabIndex = 85;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 271);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 13);
            this.label6.TabIndex = 84;
            this.label6.Text = "Permanent Address";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(45, 188);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 13);
            this.label5.TabIndex = 83;
            this.label5.Text = "Mother\'s Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(48, 146);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 13);
            this.label4.TabIndex = 82;
            this.label4.Text = "Father\'s Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(406, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 81;
            this.label3.Text = "Last Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(168, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 80;
            this.label2.Text = "First Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(88, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 79;
            this.label1.Text = "Name";
            // 
            // PAddressTextBox
            // 
            this.PAddressTextBox.Location = new System.Drawing.Point(129, 268);
            this.PAddressTextBox.Name = "PAddressTextBox";
            this.PAddressTextBox.Size = new System.Drawing.Size(386, 20);
            this.PAddressTextBox.TabIndex = 78;
            // 
            // MotherLastNameTextBox
            // 
            this.MotherLastNameTextBox.Location = new System.Drawing.Point(370, 185);
            this.MotherLastNameTextBox.Name = "MotherLastNameTextBox";
            this.MotherLastNameTextBox.Size = new System.Drawing.Size(145, 20);
            this.MotherLastNameTextBox.TabIndex = 77;
            // 
            // MotherFirstNameTextBox
            // 
            this.MotherFirstNameTextBox.Location = new System.Drawing.Point(129, 185);
            this.MotherFirstNameTextBox.Name = "MotherFirstNameTextBox";
            this.MotherFirstNameTextBox.Size = new System.Drawing.Size(141, 20);
            this.MotherFirstNameTextBox.TabIndex = 76;
            // 
            // FatherLastNameTextBox
            // 
            this.FatherLastNameTextBox.Location = new System.Drawing.Point(370, 143);
            this.FatherLastNameTextBox.Name = "FatherLastNameTextBox";
            this.FatherLastNameTextBox.Size = new System.Drawing.Size(145, 20);
            this.FatherLastNameTextBox.TabIndex = 75;
            // 
            // FatherFirstNameTextBox
            // 
            this.FatherFirstNameTextBox.Location = new System.Drawing.Point(129, 143);
            this.FatherFirstNameTextBox.Name = "FatherFirstNameTextBox";
            this.FatherFirstNameTextBox.Size = new System.Drawing.Size(141, 20);
            this.FatherFirstNameTextBox.TabIndex = 74;
            // 
            // LastNameTextBox
            // 
            this.LastNameTextBox.Location = new System.Drawing.Point(370, 99);
            this.LastNameTextBox.Name = "LastNameTextBox";
            this.LastNameTextBox.Size = new System.Drawing.Size(145, 20);
            this.LastNameTextBox.TabIndex = 73;
            // 
            // FirstNameTextBox
            // 
            this.FirstNameTextBox.Location = new System.Drawing.Point(129, 99);
            this.FirstNameTextBox.Name = "FirstNameTextBox";
            this.FirstNameTextBox.Size = new System.Drawing.Size(141, 20);
            this.FirstNameTextBox.TabIndex = 72;
            // 
            // Sign_Up
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(734, 461);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.browse_buttom);
            this.Controls.Add(this.renterImage);
            this.Controls.Add(this.ConfirmButton);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.RentedFlatComboBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.OfficeContNoTextBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.OffAddressTextBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.EmailTextbox);
            this.Controls.Add(this.ContactNoTextbox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PAddressTextBox);
            this.Controls.Add(this.MotherLastNameTextBox);
            this.Controls.Add(this.MotherFirstNameTextBox);
            this.Controls.Add(this.FatherLastNameTextBox);
            this.Controls.Add(this.FatherFirstNameTextBox);
            this.Controls.Add(this.LastNameTextBox);
            this.Controls.Add(this.FirstNameTextBox);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Name = "Sign_Up";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sign Up";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Sign_Up_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.renterImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button browse_buttom;
        private System.Windows.Forms.PictureBox renterImage;
        private System.Windows.Forms.Button ConfirmButton;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox RentedFlatComboBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox OfficeContNoTextBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox OffAddressTextBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox EmailTextbox;
        private System.Windows.Forms.TextBox ContactNoTextbox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox PAddressTextBox;
        private System.Windows.Forms.TextBox MotherLastNameTextBox;
        private System.Windows.Forms.TextBox MotherFirstNameTextBox;
        private System.Windows.Forms.TextBox FatherLastNameTextBox;
        private System.Windows.Forms.TextBox FatherFirstNameTextBox;
        private System.Windows.Forms.TextBox LastNameTextBox;
        private System.Windows.Forms.TextBox FirstNameTextBox;
    }
}

