﻿namespace Residence_provision_system
{
    partial class floors
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(floors));
            this.F6Button = new System.Windows.Forms.Button();
            this.F5Button = new System.Windows.Forms.Button();
            this.F4Button = new System.Windows.Forms.Button();
            this.F3Button = new System.Windows.Forms.Button();
            this.F2Button = new System.Windows.Forms.Button();
            this.F1Button = new System.Windows.Forms.Button();
            this.HouseAddressTextbox = new System.Windows.Forms.TextBox();
            this.HouseAddressLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // F6Button
            // 
            this.F6Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F6Button.Location = new System.Drawing.Point(407, 374);
            this.F6Button.Name = "F6Button";
            this.F6Button.Size = new System.Drawing.Size(163, 48);
            this.F6Button.TabIndex = 15;
            this.F6Button.Text = "Floor 6";
            this.F6Button.UseVisualStyleBackColor = true;
            this.F6Button.Click += new System.EventHandler(this.F6Button_Click);
            // 
            // F5Button
            // 
            this.F5Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F5Button.Location = new System.Drawing.Point(164, 374);
            this.F5Button.Name = "F5Button";
            this.F5Button.Size = new System.Drawing.Size(156, 48);
            this.F5Button.TabIndex = 14;
            this.F5Button.Text = "Floor 5";
            this.F5Button.UseVisualStyleBackColor = true;
            this.F5Button.Click += new System.EventHandler(this.F5Button_Click);
            // 
            // F4Button
            // 
            this.F4Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F4Button.Location = new System.Drawing.Point(407, 297);
            this.F4Button.Name = "F4Button";
            this.F4Button.Size = new System.Drawing.Size(163, 48);
            this.F4Button.TabIndex = 13;
            this.F4Button.Text = "Floor 4";
            this.F4Button.UseVisualStyleBackColor = true;
            this.F4Button.Click += new System.EventHandler(this.F4Button_Click);
            // 
            // F3Button
            // 
            this.F3Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F3Button.Location = new System.Drawing.Point(164, 297);
            this.F3Button.Name = "F3Button";
            this.F3Button.Size = new System.Drawing.Size(156, 48);
            this.F3Button.TabIndex = 12;
            this.F3Button.Text = "Floor 3";
            this.F3Button.UseVisualStyleBackColor = true;
            this.F3Button.Click += new System.EventHandler(this.F3Button_Click);
            // 
            // F2Button
            // 
            this.F2Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F2Button.Location = new System.Drawing.Point(407, 215);
            this.F2Button.Name = "F2Button";
            this.F2Button.Size = new System.Drawing.Size(163, 48);
            this.F2Button.TabIndex = 11;
            this.F2Button.Text = "Floor 2";
            this.F2Button.UseVisualStyleBackColor = true;
            this.F2Button.Click += new System.EventHandler(this.F2Button_Click);
            // 
            // F1Button
            // 
            this.F1Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F1Button.Location = new System.Drawing.Point(164, 215);
            this.F1Button.Name = "F1Button";
            this.F1Button.Size = new System.Drawing.Size(156, 48);
            this.F1Button.TabIndex = 10;
            this.F1Button.Text = "Floor 1";
            this.F1Button.UseVisualStyleBackColor = true;
            this.F1Button.Click += new System.EventHandler(this.F1Button_Click);
            // 
            // HouseAddressTextbox
            // 
            this.HouseAddressTextbox.Location = new System.Drawing.Point(150, 79);
            this.HouseAddressTextbox.Name = "HouseAddressTextbox";
            this.HouseAddressTextbox.ReadOnly = true;
            this.HouseAddressTextbox.Size = new System.Drawing.Size(346, 20);
            this.HouseAddressTextbox.TabIndex = 9;
            // 
            // HouseAddressLabel
            // 
            this.HouseAddressLabel.AutoSize = true;
            this.HouseAddressLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HouseAddressLabel.Location = new System.Drawing.Point(285, 39);
            this.HouseAddressLabel.Name = "HouseAddressLabel";
            this.HouseAddressLabel.Size = new System.Drawing.Size(172, 25);
            this.HouseAddressLabel.TabIndex = 8;
            this.HouseAddressLabel.Text = "House Address";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(147, 126);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 16);
            this.label1.TabIndex = 16;
            this.label1.Text = "OWNER";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(209, 123);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(157, 20);
            this.textBox1.TabIndex = 18;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(443, 125);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(141, 20);
            this.textBox2.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(372, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 16);
            this.label2.TabIndex = 20;
            this.label2.Text = "Contact";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(666, 17);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(45, 45);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 142;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(31, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(45, 45);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 141;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(209, 170);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 143;
            this.button1.Text = "edit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(324, 170);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 144;
            this.button2.Text = "save";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Candara", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(443, 170);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(116, 23);
            this.button3.TabIndex = 177;
            this.button3.Text = "Change Password";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // floors
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(734, 461);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.F6Button);
            this.Controls.Add(this.F5Button);
            this.Controls.Add(this.F4Button);
            this.Controls.Add(this.F3Button);
            this.Controls.Add(this.F2Button);
            this.Controls.Add(this.F1Button);
            this.Controls.Add(this.HouseAddressTextbox);
            this.Controls.Add(this.HouseAddressLabel);
            this.Name = "floors";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "floors";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.floors_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button F6Button;
        private System.Windows.Forms.Button F5Button;
        private System.Windows.Forms.Button F4Button;
        private System.Windows.Forms.Button F3Button;
        private System.Windows.Forms.Button F2Button;
        private System.Windows.Forms.Button F1Button;
        private System.Windows.Forms.TextBox HouseAddressTextbox;
        private System.Windows.Forms.Label HouseAddressLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}